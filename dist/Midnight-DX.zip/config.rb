preferred_syntax = :scss
http_path = '/'
css_dir = 'styles/css'
sass_dir = 'styles/sass'
relative_assets = true
line_comments = false
sourcemap = false
output_style = :expanded