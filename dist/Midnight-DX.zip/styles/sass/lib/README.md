# Mendix-UI-Framework-Lib
This is the Mendix UI Framework Library that is the base of all Mendix Themes of the DX Release.
